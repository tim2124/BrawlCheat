import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.05, green: 0.05, blue: 0.12, alpha: 1)
        buildUI()
    }

    func buildUI() {
        // Logo label
        let logo = UILabel()
        logo.text = "💥 BrawlCheat"
        logo.textColor = UIColor(red: 0.98, green: 0.72, blue: 0.1, alpha: 1)
        logo.font = UIFont.boldSystemFont(ofSize: 30)
        logo.textAlignment = .center
        logo.frame = CGRect(x: 0, y: 90, width: view.frame.width, height: 40)
        view.addSubview(logo)

        let sub = UILabel()
        sub.text = "iOS Loader v1.0"
        sub.textColor = .lightGray
        sub.font = UIFont.systemFont(ofSize: 13)
        sub.textAlignment = .center
        sub.frame = CGRect(x: 0, y: 138, width: view.frame.width, height: 20)
        view.addSubview(sub)

        let divider = UIView()
        divider.backgroundColor = UIColor.white.withAlphaComponent(0.08)
        divider.frame = CGRect(x: 30, y: 175, width: view.frame.width - 60, height: 1)
        view.addSubview(divider)

        // Debug button
        let debugBtn = makeButton(title: "⚙️  Debug Menu",
            bg: UIColor(red: 0.98, green: 0.72, blue: 0.1, alpha: 1),
            fg: .black, y: 200)
        debugBtn.addTarget(self, action: #selector(openDebug), for: .touchUpInside)
        view.addSubview(debugBtn)

        // Launch button
        let launchBtn = makeButton(title: "🚀  Launch Brawl Stars",
            bg: UIColor(red: 0.18, green: 0.48, blue: 1.0, alpha: 1),
            fg: .white, y: 270)
        launchBtn.addTarget(self, action: #selector(launchGame), for: .touchUpInside)
        view.addSubview(launchBtn)

        let status = UILabel()
        status.text = "STATUS: READY"
        status.textColor = UIColor(red: 0.3, green: 1.0, blue: 0.4, alpha: 1)
        status.font = UIFont.monospacedSystemFont(ofSize: 12, weight: .bold)
        status.textAlignment = .center
        status.frame = CGRect(x: 0, y: 345, width: view.frame.width, height: 20)
        view.addSubview(status)
    }

    func makeButton(title: String, bg: UIColor, fg: UIColor, y: CGFloat) -> UIButton {
        let btn = UIButton(type: .system)
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(fg, for: .normal)
        btn.backgroundColor = bg
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 17)
        btn.layer.cornerRadius = 14
        btn.frame = CGRect(x: 36, y: y, width: view.frame.width - 72, height: 54)
        btn.layer.shadowColor = bg.cgColor
        btn.layer.shadowOpacity = 0.4
        btn.layer.shadowOffset = CGSize(width: 0, height: 4)
        btn.layer.shadowRadius = 8
        return btn
    }

    @objc func launchGame() {
        if let url = URL(string: "brawlstars://") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }

    @objc func openDebug() {
        let vc = DebugMenuViewController()
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
}
