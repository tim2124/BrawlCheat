import UIKit

struct CheatOption {
    var name: String
    var detail: String
    var icon: String
    var enabled: Bool
}

class DebugMenuViewController: UIViewController,
    UITableViewDelegate, UITableViewDataSource {

    var cheats: [CheatOption] = [
        CheatOption(name: "Aimbot",      detail: "Auto-locks onto nearest brawler hitbox", icon: "🎯", enabled: false),
        CheatOption(name: "Spinbot",     detail: "Rapid angle rotation spam on attack",    icon: "🌀", enabled: false),
        CheatOption(name: "Auto Dodge",  detail: "Predicts projectiles, dodges automatically", icon: "⚡", enabled: false),
        CheatOption(name: "ESP Lines",   detail: "Draw lines to all players through map",  icon: "📡", enabled: false),
        CheatOption(name: "Box ESP",     detail: "Bounding box drawn around all brawlers", icon: "📦", enabled: false),
        CheatOption(name: "No Fog",      detail: "Remove fog of war visibility limit",     icon: "👁", enabled: false),
        CheatOption(name: "Rapid Fire",  detail: "Remove attack cooldown delay",           icon: "🔥", enabled: false),
        CheatOption(name: "No Spread",   detail: "Removes bullet spread on all brawlers",  icon: "🎳", enabled: false),
    ]

    let table = UITableView()
    var activeCount = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.04, green: 0.04, blue: 0.1, alpha: 1)
        buildHeader()
        buildTable()
    }

    func buildHeader() {
        let bar = UIView()
        bar.backgroundColor = UIColor(red: 0.08, green: 0.08, blue: 0.18, alpha: 1)
        bar.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 100)
        view.addSubview(bar)

        let title = UILabel()
        title.text = "⚙️  Debug Menu"
        title.textColor = UIColor(red: 0.98, green: 0.72, blue: 0.1, alpha: 1)
        title.font = UIFont.boldSystemFont(ofSize: 22)
        title.frame = CGRect(x: 20, y: 55, width: 260, height: 30)
        view.addSubview(title)

        let closeBtn = UIButton(type: .system)
        closeBtn.setTitle("✕", for: .normal)
        closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        closeBtn.frame = CGRect(x: view.frame.width - 60, y: 55, width: 44, height: 30)
        closeBtn.addTarget(self, action: #selector(close), for: .touchUpInside)
        view.addSubview(closeBtn)
    }

    func buildTable() {
        table.frame = CGRect(x: 0, y: 100, width: view.frame.width,
            height: view.frame.height - 100)
        table.backgroundColor = .clear
        table.delegate = self
        table.dataSource = self
        table.register(CheatCell.self, forCellReuseIdentifier: "cheat")
        table.separatorColor = UIColor.white.withAlphaComponent(0.07)
        table.contentInset = UIEdgeInsets(top: 8, left: 0, bottom: 20, right: 0)
        view.addSubview(table)
    }

    @objc func close() { dismiss(animated: true) }

    func tableView(_ tv: UITableView, numberOfRowsInSection s: Int) -> Int { cheats.count }
    func tableView(_ tv: UITableView, heightForRowAt ip: IndexPath) -> CGFloat { 76 }

    func tableView(_ tv: UITableView, cellForRowAt ip: IndexPath) -> UITableViewCell {
        let cell = tv.dequeueReusableCell(withIdentifier: "cheat", for: ip) as! CheatCell
        cell.configure(with: cheats[ip.row])
        cell.toggle.tag = ip.row
        cell.toggle.addTarget(self, action: #selector(toggleCheat(_:)), for: .valueChanged)
        return cell
    }

    @objc func toggleCheat(_ sender: UISwitch) {
        cheats[sender.tag].enabled = sender.isOn
        let name = cheats[sender.tag].name
        let state = sender.isOn ? "ON" : "OFF"
        print("[BrawlCheat] \(name) → \(state)")
        // Hook dispatch point: real dylib call goes here
        // BrawlHook.shared.set(cheat: name, enabled: sender.isOn)
    }
}

class CheatCell: UITableViewCell {
    let iconLabel  = UILabel()
    let nameLabel  = UILabel()
    let detailLabel = UILabel()
    let toggle     = UISwitch()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle  = .none

        iconLabel.font = UIFont.systemFont(ofSize: 22)
        iconLabel.frame = CGRect(x: 16, y: 18, width: 36, height: 36)
        contentView.addSubview(iconLabel)

        nameLabel.textColor = .white
        nameLabel.font = UIFont.boldSystemFont(ofSize: 16)
        nameLabel.frame = CGRect(x: 60, y: 14, width: 230, height: 22)
        contentView.addSubview(nameLabel)

        detailLabel.textColor = UIColor.lightGray
        detailLabel.font = UIFont.systemFont(ofSize: 12)
        detailLabel.frame = CGRect(x: 60, y: 38, width: 230, height: 18)
        contentView.addSubview(detailLabel)

        toggle.onTintColor = UIColor(red: 0.98, green: 0.72, blue: 0.1, alpha: 1)
        toggle.frame = CGRect(x: UIScreen.main.bounds.width - 76, y: 24, width: 51, height: 28)
        contentView.addSubview(toggle)
    }

    required init?(coder: NSCoder) { fatalError() }

    func configure(with c: CheatOption) {
        iconLabel.text   = c.icon
        nameLabel.text   = c.name
        detailLabel.text = c.detail
        toggle.isOn      = c.enabled
    }
}
