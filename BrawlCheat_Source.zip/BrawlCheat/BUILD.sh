#!/bin/bash
# Run this on a Mac with Xcode installed
# Output: BrawlCheat.ipa ready for KSign

echo "[*] Building BrawlCheat..."
cd "$(dirname "$0")"

xcodebuild \
  -project BrawlCheat.xcodeproj \
  -scheme BrawlCheat \
  -configuration Release \
  -sdk iphoneos \
  -archivePath ./build/BrawlCheat.xcarchive \
  archive \
  CODE_SIGNING_ALLOWED=NO

xcodebuild \
  -exportArchive \
  -archivePath ./build/BrawlCheat.xcarchive \
  -exportPath ./build/ \
  -exportOptionsPlist ExportOptions.plist

echo "[*] Done — find BrawlCheat.ipa in ./build/"
