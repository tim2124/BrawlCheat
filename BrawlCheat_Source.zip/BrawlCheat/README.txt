BrawlCheat iOS Loader
=====================
1. Open BrawlCheat.xcodeproj in Xcode
2. Set your Team under Signing & Capabilities (free Apple ID works)
3. Product → Archive
4. Distribute App → Ad Hoc → export
5. Rename exported .ipa → BrawlCheat.datei  (optional for KSign)
6. Drop into KSign → sign → install

OR run BUILD.sh on Mac with Xcode CLI tools installed.

Features in Debug Menu:
- Aimbot
- Spinbot
- Auto Dodge
- ESP Lines
- Box ESP
- No Fog
- Rapid Fire
- No Spread

Hook dispatch wired to console — real cheat logic
needs dylib injection via TrollStore or jailbreak.
